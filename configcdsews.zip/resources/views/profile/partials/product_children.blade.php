@foreach($children as $childCategory)
    <li id="menu-item-{{ $childCategory->id }}"
        class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children dropdown-submenu">
        <a title="{{ $childCategory->name }}"
           href="{{ route('category.show', ['categoryName' => Str::slug(str_replace(['/', '&', '+'], ' ', $childCategory->name))]) }}">
            {{ $childCategory->name }}
        </a>
        @if($childCategory->children->isNotEmpty())
            <ul role="menu" class="dropdown-menu">
                {{-- Recursively call this partial for the next level of children --}}
                @include('partials.product_children', ['children' => $childCategory->children])
            </ul>
        @endif
    </li>
@endforeach