<div class="bg-white rounded-xl shadow-lg overflow-hidden transform transition-transform hover:scale-105 duration-300">
    <img src="{{ $product['imageUrl'] }}" alt="{{ $product['name'] }}" class="w-full h-48 object-cover" onerror="this.onerror=null;this.src='https://placehold.co/300x200/F0F9FF/1F2937?text={{ urlencode($product['name']) }}';" />
    <div class="p-4">
        <h3 class="font-semibold text-lg text-gray-800 truncate">{{ $product['name'] }}</h3>
        <p class="text-sm text-gray-500">{{ $product['category'] }}</p>
        <div class="flex items-center mt-2">
            <span class="text-yellow-500 text-sm">
                @for ($i = 0; $i < floor($product['rating']); $i++)
                    &#9733; <!-- Unicode star character -->
                @endfor
            </span>
            <span class="ml-1 text-gray-600 text-sm">({{ $product['rating'] }})</span>
        </div>
        <p class="text-xl font-bold text-indigo-600 mt-2">${{ number_format($product['price'], 2) }}</p>
        <button class="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors duration-300">
            Add to Cart
        </button>
    </div>
</div>
