@extends('layouts.simslayout')

@section('content')
        <!-- BEGIN: Main Menu-->
        <div class="horizontal-menu-wrapper">
            <div
                class="header-navbar navbar-expand-sm navbar navbar-horizontal floating-nav navbar-light navbar-shadow menu-border container-xxl"
                role="navigation"
                data-menu="menu-wrapper"
                data-menu-type="floating-nav"
            >
                <div class="navbar-header">
                    <ul class="nav navbar-nav flex-row">
                        <li class="nav-item me-auto">
                            <a
                                class="navbar-brand"
                                href="https://Albertina.com"
                                ><span class="brand-logo">
                                    <svg
                                        viewbox="0 0 139 95"
                                        version="1.1"
                                        xmlns="http://www.w3.org/2000/svg"
                                        xmlns:xlink="http://www.w3.org/1999/xlink"
                                        height="24"
                                    >
                                        <defs>
                                            <lineargradient
                                                id="linearGradient-1"
                                                x1="100%"
                                                y1="10.5120544%"
                                                x2="50%"
                                                y2="89.4879456%"
                                            >
                                                <stop
                                                    stop-color="#000000"
                                                    offset="0%"
                                                ></stop>
                                                <stop
                                                    stop-color="#FFFFFF"
                                                    offset="100%"
                                                ></stop>
                                            </lineargradient>
                                            <lineargradient
                                                id="linearGradient-2"
                                                x1="64.0437835%"
                                                y1="46.3276743%"
                                                x2="37.373316%"
                                                y2="100%"
                                            >
                                                <stop
                                                    stop-color="#EEEEEE"
                                                    stop-opacity="0"
                                                    offset="0%"
                                                ></stop>
                                                <stop
                                                    stop-color="#FFFFFF"
                                                    offset="100%"
                                                ></stop>
                                            </lineargradient>
                                        </defs>
                                        <g
                                            id="Page-1"
                                            stroke="none"
                                            stroke-width="1"
                                            fill="none"
                                            fill-rule="evenodd"
                                        >
                                            <g
                                                id="Artboard"
                                                transform="translate(-400.000000, -178.000000)"
                                            >
                                                <g
                                                    id="Group"
                                                    transform="translate(400.000000, 178.000000)"
                                                >
                                                    <path
                                                        class="text-primary"
                                                        id="Path"
                                                        d="M-5.68434189e-14,2.84217094e-14 L39.1816085,2.84217094e-14 L69.3453773,32.2519224 L101.428699,2.84217094e-14 L138.784583,2.84217094e-14 L138.784199,29.8015838 C137.958931,37.3510206 135.784352,42.5567762 132.260463,45.4188507 C128.736573,48.2809251 112.33867,64.5239941 83.0667527,94.1480575 L56.2750821,94.1480575 L6.71554594,44.4188507 C2.46876683,39.9813776 0.345377275,35.1089553 0.345377275,29.8015838 C0.345377275,24.4942122 0.230251516,14.560351 -5.68434189e-14,2.84217094e-14 Z"
                                                        style="
                                                            fill: currentColor;
                                                        "
                                                    ></path>
                                                    <path
                                                        id="Path1"
                                                        d="M69.3453773,32.2519224 L101.428699,1.42108547e-14 L138.784583,1.42108547e-14 L138.784199,29.8015838 C137.958931,37.3510206 135.784352,42.5567762 132.260463,45.4188507 C128.736573,48.2809251 112.33867,64.5239941 83.0667527,94.1480575 L56.2750821,94.1480575 L32.8435758,70.5039241 L69.3453773,32.2519224 Z"
                                                        fill="url(#linearGradient-1)"
                                                        opacity="0.2"
                                                    ></path>
                                                    <polygon
                                                        id="Path-2"
                                                        fill="#000000"
                                                        opacity="0.049999997"
                                                        points="69.3922914 32.4202615 32.8435758 70.5039241 54.0490008 16.1851325"
                                                    ></polygon>
                                                    <polygon
                                                        id="Path-21"
                                                        fill="#000000"
                                                        opacity="0.099999994"
                                                        points="69.3922914 32.4202615 32.8435758 70.5039241 58.3683556 20.7402338"
                                                    ></polygon>
                                                    <polygon
                                                        id="Path-3"
                                                        fill="url(#linearGradient-2)"
                                                        opacity="0.099999994"
                                                        points="101.428699 0 83.0667527 94.1480575 130.378721 47.0740288"
                                                    ></polygon>
                                                </g>
                                            </g>
                                        </g></svg
                                ></span>
                                <h2 class="brand-text mb-0">Vuexy</h2>
                            </a>
                        </li>
                        <li class="nav-item nav-toggle">
                            <a
                                class="nav-link modern-nav-toggle pe-0"
                                data-bs-toggle="collapse"
                                ><i
                                    class="d-block d-xl-none text-primary toggle-icon font-medium-4"
                                    data-feather="x"
                                ></i
                            ></a>
                        </li>
                    </ul>
                </div>
                <div class="shadow-bottom"></div>
                <!-- Horizontal menu content-->
                <div
                    class="navbar-container main-menu-content"
                    data-menu="menu-container"
                >
                    <!-- include ../../../includes/mixins-->
                    <ul
                        class="nav navbar-nav"
                        id="main-menu-navigation"
                        data-menu="menu-navigation"
                    >
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="index.html"
                                data-bs-toggle="dropdown"
                                ><i data-feather="home"></i
                                ><span data-i18n="Dashboards"
                                    >Dashboards</span
                                ></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="dashboard-analytics.html"
                                        data-bs-toggle=""
                                        data-i18n="Analytics"
                                        ><i data-feather="activity"></i
                                        ><span data-i18n="Analytics"
                                            >Analytics</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="dashboard-ecommerce.html"
                                        data-bs-toggle=""
                                        data-i18n="eCommerce"
                                        ><i data-feather="shopping-cart"></i
                                        ><span data-i18n="eCommerce"
                                            >eCommerce</span
                                        ></a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="#"
                                data-bs-toggle="dropdown"
                                ><i data-feather="package"></i
                                ><span data-i18n="Apps">Apps</span></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="app-email.html"
                                        data-bs-toggle=""
                                        data-i18n="Email"
                                        ><i data-feather="mail"></i
                                        ><span data-i18n="Email">Email</span></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="app-chat.html"
                                        data-bs-toggle=""
                                        data-i18n="Chat"
                                        ><i data-feather="message-square"></i
                                        ><span data-i18n="Chat">Chat</span></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="app-todo.html"
                                        data-bs-toggle=""
                                        data-i18n="Todo"
                                        ><i data-feather="check-square"></i
                                        ><span data-i18n="Todo">Todo</span></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="app-calendar.html"
                                        data-bs-toggle=""
                                        data-i18n="Calendar"
                                        ><i data-feather="calendar"></i
                                        ><span data-i18n="Calendar"
                                            >Calendar</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="app-kanban.html"
                                        data-bs-toggle=""
                                        data-i18n="Kanban"
                                        ><i data-feather="grid"></i
                                        ><span data-i18n="Kanban"
                                            >Kanban</span
                                        ></a
                                    >
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Invoice"
                                        ><i data-feather="file-text"></i
                                        ><span data-i18n="Invoice"
                                            >Invoice</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-invoice-list.html"
                                                data-bs-toggle=""
                                                data-i18n="List"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="List"
                                                    >List</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-invoice-preview.html"
                                                data-bs-toggle=""
                                                data-i18n="Preview"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Preview"
                                                    >Preview</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-invoice-edit.html"
                                                data-bs-toggle=""
                                                data-i18n="Edit"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Edit"
                                                    >Edit</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-invoice-add.html"
                                                data-bs-toggle=""
                                                data-i18n="Add"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Add"
                                                    >Add</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="app-file-manager.html"
                                        data-bs-toggle=""
                                        data-i18n="File Manager"
                                        ><i data-feather="save"></i
                                        ><span data-i18n="File Manager"
                                            >File Manager</span
                                        ></a
                                    >
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Roles &amp; Permission"
                                        ><i data-feather="shield"></i
                                        ><span
                                            data-i18n="Roles &amp; Permission"
                                            >Roles &amp; Permission</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-access-roles.html"
                                                data-bs-toggle=""
                                                data-i18n="Roles"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Roles"
                                                    >Roles</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-access-permission.html"
                                                data-bs-toggle=""
                                                data-i18n="Permission"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Permission"
                                                    >Permission</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="eCommerce"
                                        ><i data-feather="shopping-cart"></i
                                        ><span data-i18n="eCommerce"
                                            >eCommerce</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-ecommerce-shop.html"
                                                data-bs-toggle=""
                                                data-i18n="Shop"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Shop"
                                                    >Shop</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-ecommerce-details.html"
                                                data-bs-toggle=""
                                                data-i18n="Details"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Details"
                                                    >Details</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-ecommerce-wishlist.html"
                                                data-bs-toggle=""
                                                data-i18n="Wishlist"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Wishlist"
                                                    >Wishlist</span
                                                ></a
                                            >
                                        </li>
                                        <li class="active" data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-ecommerce-checkout.html"
                                                data-bs-toggle=""
                                                data-i18n="Checkout"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Checkout"
                                                    >Checkout</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="User"
                                        ><i data-feather="user"></i
                                        ><span data-i18n="User">User</span></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="app-user-list.html"
                                                data-bs-toggle=""
                                                data-i18n="List"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="List"
                                                    >List</span
                                                ></a
                                            >
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="View"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="View"
                                                    >View</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="app-user-view-account.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Account"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Account"
                                                            >Account</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="app-user-view-security.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Security"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Security"
                                                            >Security</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="app-user-view-billing.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Billing &amp; Plans"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Billing &amp; Plans"
                                                            >Billing &amp;
                                                            Plans</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="app-user-view-notifications.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Notifications"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Notifications"
                                                            >Notifications</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="app-user-view-connections.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Connections"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Connections"
                                                            >Connections</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="#"
                                data-bs-toggle="dropdown"
                                ><i data-feather="layers"></i
                                ><span data-i18n="User Interface"
                                    >User Interface</span
                                ></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="ui-typography.html"
                                        data-bs-toggle=""
                                        data-i18n="Typography"
                                        ><i data-feather="type"></i
                                        ><span data-i18n="Typography"
                                            >Typography</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="ui-feather.html"
                                        data-bs-toggle=""
                                        data-i18n="Feather"
                                        ><i data-feather="eye"></i
                                        ><span data-i18n="Feather"
                                            >Feather</span
                                        ></a
                                    >
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Cards"
                                        ><i data-feather="credit-card"></i
                                        ><span data-i18n="Cards">Cards</span></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="card-basic.html"
                                                data-bs-toggle=""
                                                data-i18n="Basic"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Basic"
                                                    >Basic</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="card-advance.html"
                                                data-bs-toggle=""
                                                data-i18n="Advance"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Advance"
                                                    >Advance</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="card-statistics.html"
                                                data-bs-toggle=""
                                                data-i18n="Statistics"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Statistics"
                                                    >Statistics</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="card-analytics.html"
                                                data-bs-toggle=""
                                                data-i18n="Analytics"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Analytics"
                                                    >Analytics</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="card-actions.html"
                                                data-bs-toggle=""
                                                data-i18n="Card Actions"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Card Actions"
                                                    >Card Actions</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Components"
                                        ><i data-feather="briefcase"></i
                                        ><span data-i18n="Components"
                                            >Components</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-accordion.html"
                                                data-bs-toggle=""
                                                data-i18n="Accordion"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Accordion"
                                                    >Accordion</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-alerts.html"
                                                data-bs-toggle=""
                                                data-i18n="Alerts"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Alerts"
                                                    >Alerts</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-avatar.html"
                                                data-bs-toggle=""
                                                data-i18n="Avatar"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Avatar"
                                                    >Avatar</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-badges.html"
                                                data-bs-toggle=""
                                                data-i18n="Badges"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Badges"
                                                    >Badges</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-breadcrumbs.html"
                                                data-bs-toggle=""
                                                data-i18n="Breadcrumbs"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Breadcrumbs"
                                                    >Breadcrumbs</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-buttons.html"
                                                data-bs-toggle=""
                                                data-i18n="Buttons"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Buttons"
                                                    >Buttons</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-carousel.html"
                                                data-bs-toggle=""
                                                data-i18n="Carousel"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Carousel"
                                                    >Carousel</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-collapse.html"
                                                data-bs-toggle=""
                                                data-i18n="Collapse"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Collapse"
                                                    >Collapse</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-divider.html"
                                                data-bs-toggle=""
                                                data-i18n="Divider"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Divider"
                                                    >Divider</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-dropdowns.html"
                                                data-bs-toggle=""
                                                data-i18n="Dropdowns"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Dropdowns"
                                                    >Dropdowns</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-list-group.html"
                                                data-bs-toggle=""
                                                data-i18n="List Group"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="List Group"
                                                    >List Group</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-modals.html"
                                                data-bs-toggle=""
                                                data-i18n="Modals"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Modals"
                                                    >Modals</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-navs-component.html"
                                                data-bs-toggle=""
                                                data-i18n="Navs Component"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Navs Component"
                                                    >Navs Component</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-offcanvas.html"
                                                data-bs-toggle=""
                                                data-i18n="Offcanvas"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Offcanvas"
                                                    >Offcanvas</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-pagination.html"
                                                data-bs-toggle=""
                                                data-i18n="Pagination"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Pagination"
                                                    >Pagination</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-pill-badges.html"
                                                data-bs-toggle=""
                                                data-i18n="Pill Badges"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Pill Badges"
                                                    >Pill Badges</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-pills-component.html"
                                                data-bs-toggle=""
                                                data-i18n="Pills Component"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Pills Component"
                                                    >Pills Component</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-popovers.html"
                                                data-bs-toggle=""
                                                data-i18n="Popovers"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Popovers"
                                                    >Popovers</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-progress.html"
                                                data-bs-toggle=""
                                                data-i18n="Progress"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Progress"
                                                    >Progress</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-spinner.html"
                                                data-bs-toggle=""
                                                data-i18n="Spinner"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Spinner"
                                                    >Spinner</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-tabs-component.html"
                                                data-bs-toggle=""
                                                data-i18n="Tabs Component"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Tabs Component"
                                                    >Tabs Component</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-timeline.html"
                                                data-bs-toggle=""
                                                data-i18n="Timeline"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Timeline"
                                                    >Timeline</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-bs-toast.html"
                                                data-bs-toggle=""
                                                data-i18n="Toasts"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Toasts"
                                                    >Toasts</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="component-tooltips.html"
                                                data-bs-toggle=""
                                                data-i18n="Tooltips"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Tooltips"
                                                    >Tooltips</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Extensions"
                                        ><i data-feather="box"></i
                                        ><span data-i18n="Extensions"
                                            >Extensions</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-sweet-alerts.html"
                                                data-bs-toggle=""
                                                data-i18n="Sweet Alert"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Sweet Alert"
                                                    >Sweet Alert</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-blockui.html"
                                                data-bs-toggle=""
                                                data-i18n="Block UI"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Block UI"
                                                    >BlockUI</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-toastr.html"
                                                data-bs-toggle=""
                                                data-i18n="Toastr"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Toastr"
                                                    >Toastr</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-sliders.html"
                                                data-bs-toggle=""
                                                data-i18n="Sliders"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Sliders"
                                                    >Sliders</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-drag-drop.html"
                                                data-bs-toggle=""
                                                data-i18n="Drag &amp; Drop"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Drag &amp; Drop"
                                                    >Drag &amp; Drop</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-tour.html"
                                                data-bs-toggle=""
                                                data-i18n="Tour"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Tour"
                                                    >Tour</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-clipboard.html"
                                                data-bs-toggle=""
                                                data-i18n="Clipboard"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Clipboard"
                                                    >Clipboard</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-media-player.html"
                                                data-bs-toggle=""
                                                data-i18n="Media player"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Media player"
                                                    >Media Player</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-context-menu.html"
                                                data-bs-toggle=""
                                                data-i18n="Context Menu"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Context Menu"
                                                    >Context Menu</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-swiper.html"
                                                data-bs-toggle=""
                                                data-i18n="swiper"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="swiper"
                                                    >Swiper</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-tree.html"
                                                data-bs-toggle=""
                                                data-i18n="Tree"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Tree"
                                                    >Tree</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-ratings.html"
                                                data-bs-toggle=""
                                                data-i18n="Ratings"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Ratings"
                                                    >Ratings</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="ext-component-i18n.html"
                                                data-bs-toggle=""
                                                data-i18n="l18n"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="l18n"
                                                    >l18n</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Page Layouts"
                                        ><i data-feather="layout"></i
                                        ><span data-i18n="Page Layouts"
                                            >Page Layouts</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="layout-full.html"
                                                data-bs-toggle=""
                                                data-i18n="Layout Full"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Layout Full"
                                                    >Layout Full</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="layout-without-menu.html"
                                                data-bs-toggle=""
                                                data-i18n="Without Menu"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Without Menu"
                                                    >Without Menu</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="layout-empty.html"
                                                data-bs-toggle=""
                                                data-i18n="Layout Empty"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Layout Empty"
                                                    >Layout Empty</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="layout-blank.html"
                                                data-bs-toggle=""
                                                data-i18n="Layout Blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Layout Blank"
                                                    >Layout Blank</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="#"
                                data-bs-toggle="dropdown"
                                ><i data-feather="edit"></i
                                ><span data-i18n="Forms &amp; Tables"
                                    >Forms &amp; Tables</span
                                ></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Form Elements"
                                        ><i data-feather="copy"></i
                                        ><span data-i18n="Form Elements"
                                            >Form Elements</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-input.html"
                                                data-bs-toggle=""
                                                data-i18n="Input"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Input"
                                                    >Input</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-input-groups.html"
                                                data-bs-toggle=""
                                                data-i18n="Input Groups"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Input Groups"
                                                    >Input Groups</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-input-mask.html"
                                                data-bs-toggle=""
                                                data-i18n="Input Mask"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Input Mask"
                                                    >Input Mask</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-textarea.html"
                                                data-bs-toggle=""
                                                data-i18n="Textarea"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Textarea"
                                                    >Textarea</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-checkbox.html"
                                                data-bs-toggle=""
                                                data-i18n="Checkbox"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Checkbox"
                                                    >Checkbox</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-radio.html"
                                                data-bs-toggle=""
                                                data-i18n="Radio"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Radio"
                                                    >Radio</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-custom-options.html"
                                                data-bs-toggle=""
                                                data-i18n="Custom Options"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Custom Options"
                                                    >Custom Options</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-switch.html"
                                                data-bs-toggle=""
                                                data-i18n="Switch"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Switch"
                                                    >Switch</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-select.html"
                                                data-bs-toggle=""
                                                data-i18n="Select"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Select"
                                                    >Select</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-number-input.html"
                                                data-bs-toggle=""
                                                data-i18n="Number Input"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Number Input"
                                                    >Number Input</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-file-uploader.html"
                                                data-bs-toggle=""
                                                data-i18n="File Uploader"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="File Uploader"
                                                    >File Uploader</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-quill-editor.html"
                                                data-bs-toggle=""
                                                data-i18n="Quill Editor"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Quill Editor"
                                                    >Quill Editor</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="form-date-time-picker.html"
                                                data-bs-toggle=""
                                                data-i18n="Date &amp; Time Picker"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Date &amp; Time Picker"
                                                    >Date &amp; Time
                                                    Picker</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="form-layout.html"
                                        data-bs-toggle=""
                                        data-i18n="Form Layout"
                                        ><i data-feather="box"></i
                                        ><span data-i18n="Form Layout"
                                            >Form Layout</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="form-wizard.html"
                                        data-bs-toggle=""
                                        data-i18n="Form Wizard"
                                        ><i data-feather="package"></i
                                        ><span data-i18n="Form Wizard"
                                            >Form Wizard</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="form-validation.html"
                                        data-bs-toggle=""
                                        data-i18n="Form Validation"
                                        ><i data-feather="check-circle"></i
                                        ><span data-i18n="Form Validation"
                                            >Form Validation</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="form-repeater.html"
                                        data-bs-toggle=""
                                        data-i18n="Form Repeater"
                                        ><i data-feather="rotate-cw"></i
                                        ><span data-i18n="Form Repeater"
                                            >Form Repeater</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="table-bootstrap.html"
                                        data-bs-toggle=""
                                        data-i18n="Table"
                                        ><i data-feather="server"></i
                                        ><span data-i18n="Table">Table</span></a
                                    >
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Datatable"
                                        ><i data-feather="grid"></i
                                        ><span data-i18n="Datatable"
                                            >Datatable</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="table-datatable-basic.html"
                                                data-bs-toggle=""
                                                data-i18n="Basic"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Basic"
                                                    >Basic</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="table-datatable-advanced.html"
                                                data-bs-toggle=""
                                                data-i18n="Advanced"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Advanced"
                                                    >Advanced</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="#"
                                data-bs-toggle="dropdown"
                                ><i data-feather="file-text"></i
                                ><span data-i18n="Pages">Pages</span></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Authentication"
                                        ><i data-feather="unlock"></i
                                        ><span data-i18n="Authentication"
                                            >Authentication</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Login"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Login"
                                                    >Login</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-login-basic.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Basic"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Basic"
                                                            >Basic</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-login-cover.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Cover"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Cover"
                                                            >Cover</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Register"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Register"
                                                    >Register</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-register-basic.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Basic"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Basic"
                                                            >Basic</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-register-cover.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Cover"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Cover"
                                                            >Cover</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-register-multisteps.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Multi-Steps"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Multi-Steps"
                                                            >Multi-Steps</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Forgot Password"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Forgot Password"
                                                    >Forgot Password</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-forgot-password-basic.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Basic"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Basic"
                                                            >Basic</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-forgot-password-cover.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Cover"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Cover"
                                                            >Cover</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Reset Password"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Reset Password"
                                                    >Reset Password</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-reset-password-basic.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Basic"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Basic"
                                                            >Basic</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-reset-password-cover.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Cover"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Cover"
                                                            >Cover</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Verify Email"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Verify Email"
                                                    >Verify Email</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-verify-email-basic.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Basic"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Basic"
                                                            >Basic</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-verify-email-cover.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Cover"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Cover"
                                                            >Cover</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Two Steps"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Two Steps"
                                                    >Two Steps</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-two-steps-basic.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Basic"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Basic"
                                                            >Basic</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="auth-two-steps-cover.html"
                                                        data-bs-toggle=""
                                                        data-i18n="Cover"
                                                        target="_blank"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span data-i18n="Cover"
                                                            >Cover</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Account Settings"
                                        ><i data-feather="settings"></i
                                        ><span data-i18n="Account Settings"
                                            >Account Settings</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-account-settings-account.html"
                                                data-bs-toggle=""
                                                data-i18n="Account"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Account"
                                                    >Account</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-account-settings-security.html"
                                                data-bs-toggle=""
                                                data-i18n="Security"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Security"
                                                    >Security</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-account-settings-billing.html"
                                                data-bs-toggle=""
                                                data-i18n="Billings &amp; Plans"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Billings &amp; Plans"
                                                    >Billings &amp; Plans</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-account-settings-notifications.html"
                                                data-bs-toggle=""
                                                data-i18n="Notifications"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Notifications"
                                                    >Notifications</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-account-settings-connections.html"
                                                data-bs-toggle=""
                                                data-i18n="Connections"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Connections"
                                                    >Connections</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="page-profile.html"
                                        data-bs-toggle=""
                                        data-i18n="Profile"
                                        ><i data-feather="user"></i
                                        ><span data-i18n="Profile"
                                            >Profile</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="page-faq.html"
                                        data-bs-toggle=""
                                        data-i18n="FAQ"
                                        ><i data-feather="help-circle"></i
                                        ><span data-i18n="FAQ">FAQ</span></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="page-knowledge-base.html"
                                        data-bs-toggle=""
                                        data-i18n="Knowledge Base"
                                        ><i data-feather="info"></i
                                        ><span data-i18n="Knowledge Base"
                                            >Knowledge Base</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="page-pricing.html"
                                        data-bs-toggle=""
                                        data-i18n="Pricing"
                                        ><i data-feather="dollar-sign"></i
                                        ><span data-i18n="Pricing"
                                            >Pricing</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="page-license.html"
                                        data-bs-toggle=""
                                        data-i18n="License"
                                        ><i data-feather="credit-card"></i
                                        ><span data-i18n="License"
                                            >License</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="page-api-key.html"
                                        data-bs-toggle=""
                                        data-i18n="API Key"
                                        ><i data-feather="key"></i
                                        ><span data-i18n="API Key"
                                            >API Key</span
                                        ></a
                                    >
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Blog"
                                        ><i data-feather="clipboard"></i
                                        ><span data-i18n="Blog">Blog</span></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-blog-list.html"
                                                data-bs-toggle=""
                                                data-i18n="List"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="List"
                                                    >List</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-blog-detail.html"
                                                data-bs-toggle=""
                                                data-i18n="Detail"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Detail"
                                                    >Detail</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-blog-edit.html"
                                                data-bs-toggle=""
                                                data-i18n="Edit"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Edit"
                                                    >Edit</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Mail Template"
                                        ><i data-feather="mail"></i
                                        ><span data-i18n="Mail Template"
                                            >Mail Template</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="https://pixinvent.com/demo/vuexy-mail-template/mail-welcome.html"
                                                data-bs-toggle=""
                                                data-i18n="Welcome"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Welcome"
                                                    >Welcome</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="https://pixinvent.com/demo/vuexy-mail-template/mail-reset-password.html"
                                                data-bs-toggle=""
                                                data-i18n="Reset Password"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Reset Password"
                                                    >Reset Password</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="https://pixinvent.com/demo/vuexy-mail-template/mail-verify-email.html"
                                                data-bs-toggle=""
                                                data-i18n="Verify Email"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Verify Email"
                                                    >Verify Email</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="https://pixinvent.com/demo/vuexy-mail-template/mail-deactivate-account.html"
                                                data-bs-toggle=""
                                                data-i18n="Deactivate Account"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Deactivate Account"
                                                    >Deactivate Account</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="https://pixinvent.com/demo/vuexy-mail-template/mail-invoice.html"
                                                data-bs-toggle=""
                                                data-i18n="Invoice"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Invoice"
                                                    >Invoice</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="https://pixinvent.com/demo/vuexy-mail-template/mail-promotional.html"
                                                data-bs-toggle=""
                                                data-i18n="Promotional"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Promotional"
                                                    >Promotional</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Miscellaneous"
                                        ><i data-feather="file"></i
                                        ><span data-i18n="Miscellaneous"
                                            >Miscellaneous</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-misc-coming-soon.html"
                                                data-bs-toggle=""
                                                data-i18n="Coming Soon"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Coming Soon"
                                                    >Coming Soon</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-misc-not-authorized.html"
                                                data-bs-toggle=""
                                                data-i18n="Not Authorized"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span
                                                    data-i18n="Not Authorized"
                                                    >Not Authorized</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-misc-under-maintenance.html"
                                                data-bs-toggle=""
                                                data-i18n="Maintenance"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Maintenance"
                                                    >Maintenance</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="page-misc-error.html"
                                                data-bs-toggle=""
                                                data-i18n="Error"
                                                target="_blank"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Error"
                                                    >Error</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="modal-examples.html"
                                        data-bs-toggle=""
                                        data-i18n="Modal Examples"
                                        ><i data-feather="square"></i
                                        ><span data-i18n="Modal Examples"
                                            >Modal Examples</span
                                        ></a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="#"
                                data-bs-toggle="dropdown"
                                ><i data-feather="bar-chart-2"></i
                                ><span data-i18n="Charts &amp; Maps"
                                    >Charts &amp; Maps</span
                                ></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Charts"
                                        ><i data-feather="pie-chart"></i
                                        ><span data-i18n="Charts"
                                            >Charts</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="chart-apex.html"
                                                data-bs-toggle=""
                                                data-i18n="Apex"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Apex"
                                                    >Apex</span
                                                ></a
                                            >
                                        </li>
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="chart-chartjs.html"
                                                data-bs-toggle=""
                                                data-i18n="Chartjs"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Chartjs"
                                                    >Chartjs</span
                                                ></a
                                            >
                                        </li>
                                    </ul>
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="maps-leaflet.html"
                                        data-bs-toggle=""
                                        data-i18n="Leaflet Maps"
                                        ><i data-feather="map"></i
                                        ><span data-i18n="Leaflet Maps"
                                            >Leaflet Maps</span
                                        ></a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a
                                class="dropdown-toggle nav-link d-flex align-items-center"
                                href="#"
                                data-bs-toggle="dropdown"
                                ><i data-feather="box"></i
                                ><span data-i18n="Misc">Misc</span></a
                            >
                            <ul class="dropdown-menu" data-bs-popper="none">
                                <li
                                    class="dropdown dropdown-submenu"
                                    data-menu="dropdown-submenu"
                                >
                                    <a
                                        class="dropdown-item d-flex align-items-center dropdown-toggle"
                                        href="#"
                                        data-bs-toggle="dropdown"
                                        data-i18n="Menu Levels"
                                        ><i data-feather="menu"></i
                                        ><span data-i18n="Menu Levels"
                                            >Menu Levels</span
                                        ></a
                                    >
                                    <ul
                                        class="dropdown-menu"
                                        data-bs-popper="none"
                                    >
                                        <li data-menu="">
                                            <a
                                                class="dropdown-item d-flex align-items-center"
                                                href="#"
                                                data-bs-toggle=""
                                                data-i18n="Second Level"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Second Level"
                                                    >Second Level 2.1</span
                                                ></a
                                            >
                                        </li>
                                        <li
                                            class="dropdown dropdown-submenu"
                                            data-menu="dropdown-submenu"
                                        >
                                            <a
                                                class="dropdown-item d-flex align-items-center dropdown-toggle"
                                                href="#"
                                                data-bs-toggle="dropdown"
                                                data-i18n="Second Level"
                                                ><i data-feather="circle"></i
                                                ><span data-i18n="Second Level"
                                                    >Second Level 2.2</span
                                                ></a
                                            >
                                            <ul
                                                class="dropdown-menu"
                                                data-bs-popper="none"
                                            >
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="#"
                                                        data-bs-toggle=""
                                                        data-i18n="Third Level"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Third Level"
                                                            >Third Level
                                                            3.1</span
                                                        ></a
                                                    >
                                                </li>
                                                <li data-menu="">
                                                    <a
                                                        class="dropdown-item d-flex align-items-center"
                                                        href="#"
                                                        data-bs-toggle=""
                                                        data-i18n="Third Level"
                                                        ><i
                                                            data-feather="circle"
                                                        ></i
                                                        ><span
                                                            data-i18n="Third Level"
                                                            >Third Level
                                                            3.2</span
                                                        ></a
                                                    >
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="disabled" data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href=""
                                        data-bs-toggle=""
                                        data-i18n="Disabled Menu"
                                        ><i data-feather="eye-off"></i
                                        ><span data-i18n="Disabled Menu"
                                            >Disabled Menu</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="https://pixinvent.com/demo/vuexy-html-bootstrap-admin-template/documentation"
                                        data-bs-toggle=""
                                        data-i18n="Documentation"
                                        target="_blank"
                                        ><i data-feather="folder"></i
                                        ><span data-i18n="Documentation"
                                            >Documentation</span
                                        ></a
                                    >
                                </li>
                                <li data-menu="">
                                    <a
                                        class="dropdown-item d-flex align-items-center"
                                        href="https://pixinvent.ticksy.com/"
                                        data-bs-toggle=""
                                        data-i18n="Raise Support"
                                        target="_blank"
                                        ><i data-feather="life-buoy"></i
                                        ><span data-i18n="Raise Support"
                                            >Raise Support</span
                                        ></a
                                    >
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- END: Main Menu-->

        <!-- BEGIN: Content-->
        <div class="app-content content ecommerce-application">
            <div class="content-overlay"></div>
            <div class="header-navbar-shadow"></div>
            <div class="content-wrapper container-xxl p-0">
                <div class="content-header row">
                    <div class="content-header-left col-md-9 col-12 mb-2">
                        <div class="row breadcrumbs-top">
                            <div class="col-12">
                                <h2
                                    class="content-header-title float-start mb-0"
                                >
                                    Checkout
                                </h2>
                                <div class="breadcrumb-wrapper">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="index.html">Home</a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <a href="#">eCommerce</a>
                                        </li>
                                        <li class="breadcrumb-item active">
                                            Checkout
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="content-header-right text-md-end col-md-3 col-12 d-md-block d-none"
                    >
                        <div class="mb-1 breadcrumb-right">
                            <div class="dropdown">
                                <button
                                    class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle"
                                    type="button"
                                    data-bs-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                >
                                    <i data-feather="grid"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a
                                        class="dropdown-item"
                                        href="app-todo.html"
                                        ><i
                                            class="me-1"
                                            data-feather="check-square"
                                        ></i
                                        ><span class="align-middle"
                                            >Todo</span
                                        ></a
                                    ><a
                                        class="dropdown-item"
                                        href="app-chat.html"
                                        ><i
                                            class="me-1"
                                            data-feather="message-square"
                                        ></i
                                        ><span class="align-middle"
                                            >Chat</span
                                        ></a
                                    ><a
                                        class="dropdown-item"
                                        href="app-email.html"
                                        ><i class="me-1" data-feather="mail"></i
                                        ><span class="align-middle"
                                            >Email</span
                                        ></a
                                    ><a
                                        class="dropdown-item"
                                        href="app-calendar.html"
                                        ><i
                                            class="me-1"
                                            data-feather="calendar"
                                        ></i
                                        ><span class="align-middle"
                                            >Calendar</span
                                        ></a
                                    >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-body">
                    <div class="bs-stepper checkout-tab-steps">
                        <!-- Wizard starts -->
                        <div class="bs-stepper-header">
                            <div
                                class="step"
                                data-target="#step-cart"
                                role="tab"
                                id="step-cart-trigger"
                            >
                                <button type="button" class="step-trigger">
                                    <span class="bs-stepper-box">
                                        <i
                                            data-feather="shopping-cart"
                                            class="font-medium-3"
                                        ></i>
                                    </span>
                                    <span class="bs-stepper-label">
                                        <span class="bs-stepper-title"
                                            >Cart</span
                                        >
                                        <span class="bs-stepper-subtitle"
                                            >Your Cart Items</span
                                        >
                                    </span>
                                </button>
                            </div>
                            <div class="line">
                                <i
                                    data-feather="chevron-right"
                                    class="font-medium-2"
                                ></i>
                            </div>
                            <div
                                class="step"
                                data-target="#step-address"
                                role="tab"
                                id="step-address-trigger"
                            >
                                <button type="button" class="step-trigger">
                                    <span class="bs-stepper-box">
                                        <i
                                            data-feather="home"
                                            class="font-medium-3"
                                        ></i>
                                    </span>
                                    <span class="bs-stepper-label">
                                        <span class="bs-stepper-title"
                                            >Address</span
                                        >
                                        <span class="bs-stepper-subtitle"
                                            >Enter Your Address</span
                                        >
                                    </span>
                                </button>
                            </div>
                            <div class="line">
                                <i
                                    data-feather="chevron-right"
                                    class="font-medium-2"
                                ></i>
                            </div>
                            <div
                                class="step"
                                data-target="#step-payment"
                                role="tab"
                                id="step-payment-trigger"
                            >
                                <button type="button" class="step-trigger">
                                    <span class="bs-stepper-box">
                                        <i
                                            data-feather="credit-card"
                                            class="font-medium-3"
                                        ></i>
                                    </span>
                                    <span class="bs-stepper-label">
                                        <span class="bs-stepper-title"
                                            >Payment</span
                                        >
                                        <span class="bs-stepper-subtitle"
                                            >Select Payment Method</span
                                        >
                                    </span>
                                </button>
                            </div>
                        </div>
                        <!-- Wizard ends -->

                        <div class="bs-stepper-content">
                            <!-- Checkout Place order starts -->
                            <div
                                id="step-cart"
                                class="content"
                                role="tabpanel"
                                aria-labelledby="step-cart-trigger"
                            >
                                <div
                                    id="place-order"
                                    class="list-view product-checkout"
                                >
                                    <!-- Checkout Place Order Left starts -->
                                    <div class="checkout-items">
                                        <div class="card ecommerce-card">
                                            <div class="item-img">
                                                <a
                                                    href="app-ecommerce-details.html"
                                                >
                                                    <img
                                                        src="../../../app-assets/images/pages/eCommerce/1.png"
                                                        alt="img-placeholder"
                                                    />
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <div class="item-name">
                                                    <h6 class="mb-0">
                                                        <a
                                                            href="app-ecommerce-details.html"
                                                            class="text-body"
                                                            >Apple Watch Series
                                                            5</a
                                                        >
                                                    </h6>
                                                    <span class="item-company"
                                                        >By
                                                        <a
                                                            href="#"
                                                            class="company-name"
                                                            >Apple</a
                                                        ></span
                                                    >
                                                    <div class="item-rating">
                                                        <ul
                                                            class="unstyled-list list-inline"
                                                        >
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <span class="text-success mb-1"
                                                    >In Stock</span
                                                >
                                                <div class="item-quantity">
                                                    <span class="quantity-title"
                                                        >Qty:</span
                                                    >
                                                    <div
                                                        class="quantity-counter-wrapper"
                                                    >
                                                        <div
                                                            class="input-group"
                                                        >
                                                            <input
                                                                type="text"
                                                                class="quantity-counter"
                                                                value="1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <span
                                                    class="delivery-date text-muted"
                                                    >Delivery by, Wed Apr
                                                    25</span
                                                >
                                                <span class="text-success"
                                                    >17% off 4 offers
                                                    Available</span
                                                >
                                            </div>
                                            <div
                                                class="item-options text-center"
                                            >
                                                <div class="item-wrapper">
                                                    <div class="item-cost">
                                                        <h4 class="item-price">
                                                            $19.99
                                                        </h4>
                                                        <p
                                                            class="card-text shipping"
                                                        >
                                                            <span
                                                                class="badge rounded-pill badge-light-success"
                                                                >Free
                                                                Shipping</span
                                                            >
                                                        </p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    class="btn btn-light mt-1 remove-wishlist"
                                                >
                                                    <i
                                                        data-feather="x"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span>Remove</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-cart move-cart"
                                                >
                                                    <i
                                                        data-feather="heart"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span class="text-truncate"
                                                        >Add to Wishlist</span
                                                    >
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card ecommerce-card">
                                            <div class="item-img">
                                                <a
                                                    href="app-ecommerce-details.html"
                                                >
                                                    <img
                                                        src="../../../app-assets/images/pages/eCommerce/2.png"
                                                        alt="img-placeholder"
                                                    />
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <div class="item-name">
                                                    <h6 class="mb-0">
                                                        <a
                                                            href="app-ecommerce-details.html"
                                                            class="text-body"
                                                            >Apple iPhone 11
                                                            (64GB, Black)</a
                                                        >
                                                    </h6>
                                                    <span class="item-company"
                                                        >By
                                                        <a
                                                            href="#"
                                                            class="company-name"
                                                            >Apple</a
                                                        ></span
                                                    >
                                                    <div class="item-rating">
                                                        <ul
                                                            class="unstyled-list list-inline"
                                                        >
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <span class="text-success mb-1"
                                                    >In Stock</span
                                                >
                                                <div class="item-quantity">
                                                    <span class="quantity-title"
                                                        >Qty:</span
                                                    >
                                                    <div
                                                        class="quantity-counter-wrapper"
                                                    >
                                                        <div
                                                            class="input-group"
                                                        >
                                                            <input
                                                                type="text"
                                                                class="quantity-counter"
                                                                value="1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <span
                                                    class="delivery-date text-muted"
                                                    >Delivery by, Wed Apr
                                                    24</span
                                                >
                                                <span class="text-success"
                                                    >7% off 1 offers
                                                    Available</span
                                                >
                                            </div>
                                            <div
                                                class="item-options text-center"
                                            >
                                                <div class="item-wrapper">
                                                    <div class="item-cost">
                                                        <h4 class="item-price">
                                                            $4999.99
                                                        </h4>
                                                        <p
                                                            class="card-text shipping"
                                                        >
                                                            <span
                                                                class="badge rounded-pill badge-light-success"
                                                                >Free
                                                                Shipping</span
                                                            >
                                                        </p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    class="btn btn-light mt-1 remove-wishlist"
                                                >
                                                    <i
                                                        data-feather="x"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span>Remove</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-cart move-cart"
                                                >
                                                    <i
                                                        data-feather="heart"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span class="text-truncate"
                                                        >Add to Wishlist</span
                                                    >
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card ecommerce-card">
                                            <div class="item-img">
                                                <a
                                                    href="app-ecommerce-details.html"
                                                >
                                                    <img
                                                        src="../../../app-assets/images/pages/eCommerce/3.png"
                                                        alt="img-placeholder"
                                                    />
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <div class="item-name">
                                                    <h6 class="mb-0">
                                                        <a
                                                            href="app-ecommerce-details.html"
                                                            class="text-body"
                                                            >Apple iMac
                                                            27-inch</a
                                                        >
                                                    </h6>
                                                    <span class="item-company"
                                                        >By
                                                        <a
                                                            href="#"
                                                            class="company-name"
                                                            >Apple</a
                                                        ></span
                                                    >
                                                    <div class="item-rating">
                                                        <ul
                                                            class="unstyled-list list-inline"
                                                        >
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <span class="text-success mb-1"
                                                    >In Stock</span
                                                >
                                                <div class="item-quantity">
                                                    <span class="quantity-title"
                                                        >Qty:</span
                                                    >
                                                    <div
                                                        class="quantity-counter-wrapper"
                                                    >
                                                        <div
                                                            class="input-group"
                                                        >
                                                            <input
                                                                type="text"
                                                                class="quantity-counter"
                                                                value="1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <span
                                                    class="delivery-date text-muted"
                                                    >Delivery by, Wed Apr
                                                    27</span
                                                >
                                                <span class="text-success"
                                                    >3% off 1 offers
                                                    Available</span
                                                >
                                            </div>
                                            <div
                                                class="item-options text-center"
                                            >
                                                <div class="item-wrapper">
                                                    <div class="item-cost">
                                                        <h4 class="item-price">
                                                            $4499.99
                                                        </h4>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    class="btn btn-light mt-1 remove-wishlist"
                                                >
                                                    <i
                                                        data-feather="x"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span>Remove</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-cart move-cart"
                                                >
                                                    <i
                                                        data-feather="heart"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span class="text-truncate"
                                                        >Add to Wishlist</span
                                                    >
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card ecommerce-card">
                                            <div class="item-img">
                                                <a
                                                    href="app-ecommerce-details.html"
                                                >
                                                    <img
                                                        src="../../../app-assets/images/pages/eCommerce/4.png"
                                                        alt="img-placeholder"
                                                    />
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <div class="item-name">
                                                    <h6 class="mb-0">
                                                        <a
                                                            href="app-ecommerce-details.html"
                                                            class="text-body"
                                                            >OneOdio A71 Wired
                                                            Headphones</a
                                                        >
                                                    </h6>
                                                    <span class="item-company"
                                                        >By
                                                        <a
                                                            href="#"
                                                            class="company-name"
                                                            >OneOdio</a
                                                        ></span
                                                    >
                                                    <div class="item-rating">
                                                        <ul
                                                            class="unstyled-list list-inline"
                                                        >
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <span class="text-success mb-1"
                                                    >In Stock</span
                                                >
                                                <div class="item-quantity">
                                                    <span class="quantity-title"
                                                        >Qty:</span
                                                    >
                                                    <div
                                                        class="quantity-counter-wrapper"
                                                    >
                                                        <div
                                                            class="input-group"
                                                        >
                                                            <input
                                                                type="text"
                                                                class="quantity-counter"
                                                                value="1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <span
                                                    class="delivery-date text-muted"
                                                    >Delivery by, Wed Apr
                                                    29</span
                                                >
                                                <span class="text-success"
                                                    >5% off 2 offers
                                                    Available</span
                                                >
                                            </div>
                                            <div
                                                class="item-options text-center"
                                            >
                                                <div class="item-wrapper">
                                                    <div class="item-cost">
                                                        <h4 class="item-price">
                                                            $599.99
                                                        </h4>
                                                        <p
                                                            class="card-text shipping"
                                                        >
                                                            <span
                                                                class="badge rounded-pill badge-light-success"
                                                                >Free
                                                                Shipping</span
                                                            >
                                                        </p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    class="btn btn-light mt-1 remove-wishlist"
                                                >
                                                    <i
                                                        data-feather="x"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span>Remove</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-cart move-cart"
                                                >
                                                    <i
                                                        data-feather="heart"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span class="text-truncate"
                                                        >Add to Wishlist</span
                                                    >
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card ecommerce-card">
                                            <div class="item-img">
                                                <a
                                                    href="app-ecommerce-details.html"
                                                >
                                                    <img
                                                        src="../../../app-assets/images/pages/eCommerce/5.png"
                                                        alt="img-placeholder"
                                                    />
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <div class="item-name">
                                                    <h6 class="mb-0">
                                                        <a
                                                            href="app-ecommerce-details.html"
                                                            class="text-body"
                                                            >Apple - MacBook
                                                            Air® (Latest Model)
                                                            - 13.3" Display -
                                                            Silver</a
                                                        >
                                                    </h6>
                                                    <span class="item-company"
                                                        >By
                                                        <a
                                                            href="#"
                                                            class="company-name"
                                                            >Apple</a
                                                        ></span
                                                    >
                                                    <div class="item-rating">
                                                        <ul
                                                            class="unstyled-list list-inline"
                                                        >
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <span class="text-success mb-1"
                                                    >In Stock</span
                                                >
                                                <div class="item-quantity">
                                                    <span class="quantity-title"
                                                        >Qty:</span
                                                    >
                                                    <div
                                                        class="quantity-counter-wrapper"
                                                    >
                                                        <div
                                                            class="input-group"
                                                        >
                                                            <input
                                                                type="text"
                                                                class="quantity-counter"
                                                                value="1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <span
                                                    class="delivery-date text-muted"
                                                    >Delivery by, Wed Apr
                                                    30</span
                                                >
                                                <span class="text-success"
                                                    >3% off 1 offers
                                                    Available</span
                                                >
                                            </div>
                                            <div
                                                class="item-options text-center"
                                            >
                                                <div class="item-wrapper">
                                                    <div class="item-cost">
                                                        <h4 class="item-price">
                                                            $649.99
                                                        </h4>
                                                        <p
                                                            class="card-text shipping"
                                                        >
                                                            <span
                                                                class="badge rounded-pill badge-light-success"
                                                                >Free
                                                                Shipping</span
                                                            >
                                                        </p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    class="btn btn-light mt-1 remove-wishlist"
                                                >
                                                    <i
                                                        data-feather="x"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span>Remove</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-cart move-cart"
                                                >
                                                    <i
                                                        data-feather="heart"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span class="text-truncate"
                                                        >Add to Wishlist</span
                                                    >
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card ecommerce-card">
                                            <div class="item-img">
                                                <a
                                                    href="app-ecommerce-details.html"
                                                >
                                                    <img
                                                        src="../../../app-assets/images/pages/eCommerce/6.png"
                                                        alt="img-placeholder"
                                                    />
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <div class="item-name">
                                                    <h6 class="mb-0">
                                                        <a
                                                            href="app-ecommerce-details.html"
                                                            class="text-body"
                                                            >Switch Pro
                                                            Controller
                                                        </a>
                                                    </h6>
                                                    <span class="item-company"
                                                        >By
                                                        <a
                                                            href="#"
                                                            class="company-name"
                                                            >Sharp</a
                                                        ></span
                                                    >
                                                    <div class="item-rating">
                                                        <ul
                                                            class="unstyled-list list-inline"
                                                        >
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="filled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                            <li
                                                                class="ratings-list-item"
                                                            >
                                                                <i
                                                                    data-feather="star"
                                                                    class="unfilled-star"
                                                                ></i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <span class="text-success mb-1"
                                                    >In Stock</span
                                                >
                                                <div class="item-quantity">
                                                    <span class="quantity-title"
                                                        >Qty:</span
                                                    >
                                                    <div
                                                        class="quantity-counter-wrapper"
                                                    >
                                                        <div
                                                            class="input-group"
                                                        >
                                                            <input
                                                                type="text"
                                                                class="quantity-counter"
                                                                value="1"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <span
                                                    class="delivery-date text-muted"
                                                    >Delivery by, Wed Apr
                                                    30</span
                                                >
                                                <span class="text-success"
                                                    >6% off 3 offers
                                                    Available</span
                                                >
                                            </div>
                                            <div
                                                class="item-options text-center"
                                            >
                                                <div class="item-wrapper">
                                                    <div class="item-cost">
                                                        <h4 class="item-price">
                                                            $1999.99
                                                        </h4>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    class="btn btn-light mt-1 remove-wishlist"
                                                >
                                                    <i
                                                        data-feather="x"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span>Remove</span>
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-cart move-cart"
                                                >
                                                    <i
                                                        data-feather="heart"
                                                        class="align-middle me-25"
                                                    ></i>
                                                    <span class="text-truncate"
                                                        >Add to Wishlist</span
                                                    >
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Checkout Place Order Left ends -->

                                    <!-- Checkout Place Order Right starts -->
                                    <div class="checkout-options">
                                        <div class="card">
                                            <div class="card-body">
                                                <label
                                                    class="section-label form-label mb-1"
                                                    >Options</label
                                                >
                                                <div
                                                    class="coupons input-group input-group-merge"
                                                >
                                                    <input
                                                        type="text"
                                                        class="form-control"
                                                        placeholder="Coupons"
                                                        aria-label="Coupons"
                                                        aria-describedby="input-coupons"
                                                    />
                                                    <span
                                                        class="input-group-text text-primary ps-1"
                                                        id="input-coupons"
                                                        >Apply</span
                                                    >
                                                </div>
                                                <hr />
                                                <div class="price-details">
                                                    <h6 class="price-title">
                                                        Price Details
                                                    </h6>
                                                    <ul class="list-unstyled">
                                                        <li
                                                            class="price-detail"
                                                        >
                                                            <div
                                                                class="detail-title"
                                                            >
                                                                Total MRP
                                                            </div>
                                                            <div
                                                                class="detail-amt"
                                                            >
                                                                $598
                                                            </div>
                                                        </li>
                                                        <li
                                                            class="price-detail"
                                                        >
                                                            <div
                                                                class="detail-title"
                                                            >
                                                                Bag Discount
                                                            </div>
                                                            <div
                                                                class="detail-amt discount-amt text-success"
                                                            >
                                                                -25$
                                                            </div>
                                                        </li>
                                                        <li
                                                            class="price-detail"
                                                        >
                                                            <div
                                                                class="detail-title"
                                                            >
                                                                Estimated Tax
                                                            </div>
                                                            <div
                                                                class="detail-amt"
                                                            >
                                                                $1.3
                                                            </div>
                                                        </li>
                                                        <li
                                                            class="price-detail"
                                                        >
                                                            <div
                                                                class="detail-title"
                                                            >
                                                                EMI Eligibility
                                                            </div>
                                                            <a
                                                                href="#"
                                                                class="detail-amt text-primary"
                                                                >Details</a
                                                            >
                                                        </li>
                                                        <li
                                                            class="price-detail"
                                                        >
                                                            <div
                                                                class="detail-title"
                                                            >
                                                                Delivery Charges
                                                            </div>
                                                            <div
                                                                class="detail-amt discount-amt text-success"
                                                            >
                                                                Free
                                                            </div>
                                                        </li>
                                                    </ul>
                                                    <hr />
                                                    <ul class="list-unstyled">
                                                        <li
                                                            class="price-detail"
                                                        >
                                                            <div
                                                                class="detail-title detail-total"
                                                            >
                                                                Total
                                                            </div>
                                                            <div
                                                                class="detail-amt fw-bolder"
                                                            >
                                                                $574
                                                            </div>
                                                        </li>
                                                    </ul>
                                                    <button
                                                        type="button"
                                                        class="btn btn-primary w-100 btn-next place-order"
                                                    >
                                                        Place Order
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Checkout Place Order Right ends -->
                                    </div>
                                </div>
                                <!-- Checkout Place order Ends -->
                            </div>
                            <!-- Checkout Customer Address Starts -->
                            <div
                                id="step-address"
                                class="content"
                                role="tabpanel"
                                aria-labelledby="step-address-trigger"
                            >
                                <form
                                    id="checkout-address"
                                    class="list-view product-checkout"
                                >
                                    <!-- Checkout Customer Address Left starts -->
                                    <div class="card">
                                        <div
                                            class="card-header flex-column align-items-start"
                                        >
                                            <h4 class="card-title">
                                                Add New Address
                                            </h4>
                                            <p
                                                class="card-text text-muted mt-25"
                                            >
                                                Be sure to check "Deliver to
                                                this address" when you have
                                                finished
                                            </p>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-name"
                                                            >Full Name:</label
                                                        >
                                                        <input
                                                            type="text"
                                                            id="checkout-name"
                                                            class="form-control"
                                                            name="fname"
                                                            placeholder="John Doe"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-number"
                                                            >Mobile
                                                            Number:</label
                                                        >
                                                        <input
                                                            type="number"
                                                            id="checkout-number"
                                                            class="form-control"
                                                            name="mnumber"
                                                            placeholder="0123456789"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-apt-number"
                                                            >Flat, House
                                                            No:</label
                                                        >
                                                        <input
                                                            type="number"
                                                            id="checkout-apt-number"
                                                            class="form-control"
                                                            name="apt-number"
                                                            placeholder="9447 Glen Eagles Drive"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-landmark"
                                                            >Landmark e.g. near
                                                            apollo
                                                            hospital:</label
                                                        >
                                                        <input
                                                            type="text"
                                                            id="checkout-landmark"
                                                            class="form-control"
                                                            name="landmark"
                                                            placeholder="Near Apollo Hospital"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-city"
                                                            >Town/City:</label
                                                        >
                                                        <input
                                                            type="text"
                                                            id="checkout-city"
                                                            class="form-control"
                                                            name="city"
                                                            placeholder="Tokyo"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-pincode"
                                                            >Pincode:</label
                                                        >
                                                        <input
                                                            type="number"
                                                            id="checkout-pincode"
                                                            class="form-control"
                                                            name="pincode"
                                                            placeholder="201301"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="checkout-state"
                                                            >State:</label
                                                        >
                                                        <input
                                                            type="text"
                                                            id="checkout-state"
                                                            class="form-control"
                                                            name="state"
                                                            placeholder="California"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="mb-2">
                                                        <label
                                                            class="form-label"
                                                            cfor="add-type"
                                                            >Address
                                                            Type:</label
                                                        >
                                                        <select
                                                            class="form-select"
                                                            id="add-type"
                                                        >
                                                            <option>
                                                                Home
                                                            </option>
                                                            <option>
                                                                Work
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <button
                                                        type="button"
                                                        class="btn btn-primary btn-next delivery-address"
                                                    >
                                                        Save And Deliver Here
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Checkout Customer Address Left ends -->

                                    <!-- Checkout Customer Address Right starts -->
                                    <div class="customer-card">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title">
                                                    John Doe
                                                </h4>
                                            </div>
                                            <div class="card-body actions">
                                                <p class="card-text mb-0">
                                                    9447 Glen Eagles Drive
                                                </p>
                                                <p class="card-text">
                                                    Lewis Center, OH 43035
                                                </p>
                                                <p class="card-text">
                                                    UTC-5: Eastern Standard Time
                                                    (EST)
                                                </p>
                                                <p class="card-text">
                                                    202-555-0140
                                                </p>
                                                <button
                                                    type="button"
                                                    class="btn btn-primary w-100 btn-next delivery-address mt-2"
                                                >
                                                    Deliver To This Address
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Checkout Customer Address Right ends -->
                                </form>
                            </div>
                            <!-- Checkout Customer Address Ends -->
                            <!-- Checkout Payment Starts -->
                            <div
                                id="step-payment"
                                class="content"
                                role="tabpanel"
                                aria-labelledby="step-payment-trigger"
                            >
                                <form
                                    id="checkout-payment"
                                    class="list-view product-checkout"
                                    onsubmit="return false;"
                                >
                                    <div class="payment-type">
                                        <div class="card">
                                            <div
                                                class="card-header flex-column align-items-start"
                                            >
                                                <h4 class="card-title">
                                                    Payment options
                                                </h4>
                                                <p
                                                    class="card-text text-muted mt-25"
                                                >
                                                    Be sure to click on correct
                                                    payment option
                                                </p>
                                            </div>
                                            <div class="card-body">
                                                <h6
                                                    class="card-holder-name my-75"
                                                >
                                                    John Doe
                                                </h6>
                                                <div class="form-check">
                                                    <input
                                                        type="radio"
                                                        id="customColorRadio1"
                                                        name="paymentOptions"
                                                        class="form-check-input"
                                                        checked
                                                    />
                                                    <label
                                                        class="form-check-label"
                                                        for="customColorRadio1"
                                                    >
                                                        US Unlocked Debit Card
                                                        12XX XXXX XXXX 0000
                                                    </label>
                                                </div>
                                                <div
                                                    class="customer-cvv mt-1 row row-cols-lg-auto"
                                                >
                                                    <div
                                                        class="col-3 d-flex align-items-center"
                                                    >
                                                        <label
                                                            class="mb-50 form-label"
                                                            for="card-holder-cvv"
                                                            >Enter CVV:</label
                                                        >
                                                    </div>
                                                    <div class="col-4 p-0">
                                                        <input
                                                            type="password"
                                                            class="form-control mb-50 input-cvv"
                                                            name="input-cvv"
                                                            id="card-holder-cvv"
                                                        />
                                                    </div>
                                                    <div class="col-3">
                                                        <button
                                                            type="button"
                                                            class="btn btn-primary btn-cvv mb-50"
                                                        >
                                                            Continue
                                                        </button>
                                                    </div>
                                                </div>
                                                <hr class="my-2" />
                                                <ul
                                                    class="other-payment-options list-unstyled"
                                                >
                                                    <li class="py-50">
                                                        <div class="form-check">
                                                            <input
                                                                type="radio"
                                                                id="customColorRadio2"
                                                                name="paymentOptions"
                                                                class="form-check-input"
                                                            />
                                                            <label
                                                                class="form-check-label"
                                                                for="customColorRadio2"
                                                            >
                                                                Credit / Debit /
                                                                ATM Card
                                                            </label>
                                                        </div>
                                                    </li>
                                                    <li class="py-50">
                                                        <div class="form-check">
                                                            <input
                                                                type="radio"
                                                                id="customColorRadio3"
                                                                name="paymentOptions"
                                                                class="form-check-input"
                                                            />
                                                            <label
                                                                class="form-check-label"
                                                                for="customColorRadio3"
                                                            >
                                                                Net Banking
                                                            </label>
                                                        </div>
                                                    </li>
                                                    <li class="py-50">
                                                        <div class="form-check">
                                                            <input
                                                                type="radio"
                                                                id="customColorRadio4"
                                                                name="paymentOptions"
                                                                class="form-check-input"
                                                            />
                                                            <label
                                                                class="form-check-label"
                                                                for="customColorRadio4"
                                                            >
                                                                EMI (Easy
                                                                Installment)
                                                            </label>
                                                        </div>
                                                    </li>
                                                    <li class="py-50">
                                                        <div class="form-check">
                                                            <input
                                                                type="radio"
                                                                id="customColorRadio5"
                                                                name="paymentOptions"
                                                                class="form-check-input"
                                                            />
                                                            <label
                                                                class="form-check-label"
                                                                for="customColorRadio5"
                                                            >
                                                                Cash On Delivery
                                                            </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <hr class="my-2" />
                                                <div class="gift-card mb-25">
                                                    <p class="card-text">
                                                        <i
                                                            data-feather="plus-circle"
                                                            class="me-50 font-medium-5"
                                                        ></i>
                                                        <span
                                                            class="align-middle"
                                                            >Add Gift Card</span
                                                        >
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="amount-payable checkout-options"
                                    >
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title">
                                                    Price Details
                                                </h4>
                                            </div>
                                            <div class="card-body">
                                                <ul
                                                    class="list-unstyled price-details"
                                                >
                                                    <li class="price-detail">
                                                        <div
                                                            class="details-title"
                                                        >
                                                            Price of 3 items
                                                        </div>
                                                        <div class="detail-amt">
                                                            <strong
                                                                >$699.30</strong
                                                            >
                                                        </div>
                                                    </li>
                                                    <li class="price-detail">
                                                        <div
                                                            class="details-title"
                                                        >
                                                            Delivery Charges
                                                        </div>
                                                        <div
                                                            class="detail-amt discount-amt text-success"
                                                        >
                                                            Free
                                                        </div>
                                                    </li>
                                                </ul>
                                                <hr />
                                                <ul
                                                    class="list-unstyled price-details"
                                                >
                                                    <li class="price-detail">
                                                        <div
                                                            class="details-title"
                                                        >
                                                            Amount Payable
                                                        </div>
                                                        <div
                                                            class="detail-amt fw-bolder"
                                                        >
                                                            $699.30
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- Checkout Payment Ends -->
                            <!-- </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END: Content-->

        @endsection

      