@extends('layouts.adminlayout')

@section('content')
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">

        <div class="content-header row">
            <div class="col-12 mb-2">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h2 class="content-header-title mb-0">Admin Dashboard</h2>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                    <a href="{{ route('admin.audit.index') }}" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-clock-rotate-left me-1"></i> Audit Trail
                    </a>
                </div>
            </div>
        </div>

        <div class="content-body">
            <section id="dashboard-analytics">

                {{-- ── Stat cards ── --}}
                <div class="row mt-1">
                    <div class="col-lg-4 col-sm-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <h2 class="fw-bolder mb-0">{{ number_format($totalTransactions) }}</h2>
                                    <p class="card-text">Total Orders</p>
                                </div>
                                <div class="avatar bg-light-primary p-50 m-0">
                                    <div class="avatar-content">
                                        <i class="fas fa-cart-shopping font-medium-5"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <h2 class="fw-bolder mb-0">{{ number_format($totalProducts) }}</h2>
                                    <p class="card-text">Total Products</p>
                                </div>
                                <div class="avatar bg-light-success p-50 m-0">
                                    <div class="avatar-content">
                                        <i class="fas fa-box font-medium-5"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <h2 class="fw-bolder mb-0">{{ number_format($totalUsers) }}</h2>
                                    <p class="card-text">Total Users</p>
                                </div>
                                <div class="avatar bg-light-danger p-50 m-0">
                                    <div class="avatar-content">
                                        <i class="fas fa-users font-medium-5"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- ── Row 1: Revenue (wide) + User registrations ── --}}
                <div class="row">
                    <div class="col-xl-8 col-12 mb-3">
                        @include('admin.partials._chart-card', [
                            'chartId'   => 'revenueChart',
                            'title'     => 'Revenue — Last 12 Months',
                            'icon'      => 'fa-arrow-trend-up',
                            'colorClass'=> 'success',
                            'badgeId'   => 'revenueBadge',
                        ])
                    </div>
                    <div class="col-xl-4 col-12 mb-3">
                        @include('admin.partials._chart-card', [
                            'chartId'   => 'userChart',
                            'title'     => 'New User Registrations',
                            'icon'      => 'fa-user-plus',
                            'colorClass'=> 'primary',
                            'badgeId'   => 'userBadge',
                        ])
                    </div>
                </div>

                {{-- ── Row 2: Top products + Orders/month + Order status ── --}}
                <div class="row">
                    <div class="col-xl-5 col-12 mb-3">
                        @include('admin.partials._chart-card', [
                            'chartId'   => 'productChart',
                            'title'     => 'Top 10 Products Sold',
                            'icon'      => 'fa-boxes-stacked',
                            'colorClass'=> 'success',
                            'badgeId'   => 'productBadge',
                        ])
                    </div>
                    <div class="col-xl-4 col-12 mb-3">
                        @include('admin.partials._chart-card', [
                            'chartId'   => 'transactionChart',
                            'title'     => 'Orders Per Month',
                            'icon'      => 'fa-bag-shopping',
                            'colorClass'=> 'danger',
                            'badgeId'   => 'transactionBadge',
                        ])
                    </div>
                    <div class="col-xl-3 col-12 mb-3">
                        @include('admin.partials._chart-card', [
                            'chartId'   => 'statusChart',
                            'title'     => 'Orders by Status',
                            'icon'      => 'fa-chart-pie',
                            'colorClass'=> 'warning',
                            'badgeId'   => 'statusBadge',
                        ])
                    </div>
                </div>

                {{-- ── Audit Trail ── --}}
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-header border-bottom d-flex align-items-center justify-content-between">
                                <h4 class="card-title mb-0">
                                    <i class="fas fa-wave-square me-50 text-primary" style="font-size:15px;"></i>
                                    Recent Admin Activity
                                </h4>
                                <a href="{{ route('admin.audit.index') }}" class="btn btn-sm btn-outline-primary waves-effect">
                                    View Full Audit Trail
                                </a>
                            </div>

                            @if($recentActivity->isEmpty())
                                <div class="card-body text-center text-muted py-4">
                                    <i class="fas fa-clock" style="font-size:30px;opacity:.25;"></i>
                                    <p class="mt-1 mb-0" style="font-size:13px;">No admin activity recorded yet.</p>
                                </div>
                            @else
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0" style="font-size:13px;">
                                        <thead>
                                            <tr>
                                                <th style="width:160px;">When</th>
                                                <th style="width:160px;">Admin</th>
                                                <th style="width:90px;">Event</th>
                                                <th style="width:140px;">Record</th>
                                                <th>Detail</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($recentActivity as $log)
                                            @php
                                                $eventColor = match($log->event) {
                                                    'created' => 'success',
                                                    'updated' => 'info',
                                                    'deleted' => 'danger',
                                                    default   => 'secondary',
                                                };
                                                $auditStr = fn($v) => match(true) {
                                                    is_null($v)  => '—',
                                                    is_bool($v)  => ($v ? 'true' : 'false'),
                                                    is_array($v) => \Illuminate\Support\Str::limit(json_encode($v), 50),
                                                    default      => \Illuminate\Support\Str::limit((string)$v, 50),
                                                };
                                            @endphp
                                            <tr>
                                                <td class="text-muted" style="white-space:nowrap;">
                                                    {{ $log->created_at->format('d M Y, H:i') }}<br>
                                                    <small style="font-size:11px;">{{ $log->created_at->diffForHumans() }}</small>
                                                </td>
                                                <td>
                                                    <span class="fw-bolder">{{ $log->user_name ?? 'System' }}</span>
                                                    @if($log->ip_address)
                                                        <br><small class="text-muted" style="font-size:11px;">{{ $log->ip_address }}</small>
                                                    @endif
                                                </td>
                                                <td>
                                                    <span class="badge bg-light-{{ $eventColor }} text-{{ $eventColor }}">
                                                        {{ ucfirst($log->event) }}
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="fw-bolder">{{ $log->model_label }}</span>
                                                    <span class="text-muted">&nbsp;#{{ $log->auditable_id }}</span>
                                                </td>
                                                <td style="max-width:400px;">
                                                    @if($log->event === 'updated' && $log->new_values)
                                                        @foreach($log->new_values as $field => $newVal)
                                                            <div style="white-space:normal;line-height:1.6;">
                                                                <span class="text-muted">{{ $field }}:</span>
                                                                <span class="text-danger" style="text-decoration:line-through;">{{ $auditStr($log->old_values[$field] ?? null) }}</span>
                                                                <span class="text-success">→ {{ $auditStr($newVal) }}</span>
                                                            </div>
                                                        @endforeach
                                                    @elseif($log->event === 'created')
                                                        <span class="text-muted">New record created</span>
                                                    @elseif($log->event === 'deleted')
                                                        <span class="text-muted">Record deleted</span>
                                                    @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div class="card-footer text-center py-75">
                                    <a href="{{ route('admin.audit.index') }}" class="small text-primary">
                                        See all activity &rarr;
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>

            </section>
        </div>
    </div>
</div>

<style>
.dash-chart-wrap { position: relative; min-height: 220px; }
.chart-loader, .chart-empty {
    position: absolute; inset: 0;
    display: flex; align-items: center; justify-content: center;
}
.chart-empty { flex-direction: column; text-align: center; }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {

    Chart.defaults.font.family = "'Montserrat','Helvetica Neue',Arial,sans-serif";
    Chart.defaults.font.size   = 12;
    Chart.defaults.color       = '#6e6b7b';

    const tooltipDefaults = {
        enabled: true,
        backgroundColor: '#fff',
        titleColor: '#5e5873',
        bodyColor: '#5e5873',
        borderColor: '#ebe9f1',
        borderWidth: 1,
        padding: 10,
    };

    function dataSum(arr) { return arr.reduce((a, b) => a + Number(b), 0); }

    function setBadge(id, arr, prefix) {
        const el = document.getElementById(id);
        if (!el) return;
        const s = dataSum(arr);
        el.textContent = prefix + (s > 0 ? s.toLocaleString('en-NG') : '0');
    }

    async function loadChart({ canvasId, loaderId, emptyId, badgeId, badgePrefix = '', url, type, options }) {
        const canvas = document.getElementById(canvasId);
        const loader = document.getElementById(loaderId);
        const empty  = document.getElementById(emptyId);

        if (!canvas) return;

        try {
            const res = await fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
                credentials: 'same-origin',
            });

            if (!res.ok) throw new Error('HTTP ' + res.status + ' from ' + url);

            const payload = await res.json();

            const hasData = Array.isArray(payload.datasets)
                && payload.datasets.length
                && dataSum(payload.datasets[0].data) > 0;

            if (loader) loader.style.display = 'none';

            if (!hasData) {
                if (empty) empty.style.display = 'flex';
                setBadge(badgeId, [0], badgePrefix);
                return;
            }

            canvas.style.display = 'block';
            setBadge(badgeId, payload.datasets[0].data, badgePrefix);

            new Chart(canvas.getContext('2d'), { type, data: payload, options });

        } catch (err) {
            if (loader) loader.style.display = 'none';
            if (empty)  empty.style.display  = 'flex';
            const badge = document.getElementById(badgeId);
            if (badge) { badge.textContent = 'Error'; badge.className = 'badge bg-light-danger text-danger'; }
            console.error('[Dashboard]', canvasId, err.message);
        }
    }

    const scaleOpts = {
        responsive: true,
        maintainAspectRatio: true,
        plugins: { legend: { display: false }, tooltip: tooltipDefaults },
        scales: {
            x: { grid: { display: false } },
            y: { beginAtZero: true, grid: { color: '#f0f0f0' } },
        },
    };

    // ── Revenue (line) ──────────────────────────────────────────────────────
    loadChart({
        canvasId: 'revenueChart', loaderId: 'revenueChartLoader',
        emptyId:  'revenueChartEmpty', badgeId: 'revenueBadge', badgePrefix: '₦',
        url:  '{{ url("/admin/data/revenue-analytics") }}',
        type: 'line',
        options: {
            responsive: true, maintainAspectRatio: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    ...tooltipDefaults,
                    callbacks: { label: ctx => '₦' + Number(ctx.parsed.y).toLocaleString('en-NG', { maximumFractionDigits: 0 }) },
                },
            },
            scales: {
                x: { grid: { display: false } },
                y: {
                    beginAtZero: true, grid: { color: '#f0f0f0' },
                    ticks: { callback: v => '₦' + Number(v).toLocaleString('en-NG', { maximumFractionDigits: 0 }) },
                },
            },
        },
    });

    // ── User registrations (line) ────────────────────────────────────────────
    loadChart({
        canvasId: 'userChart', loaderId: 'userChartLoader',
        emptyId:  'userChartEmpty', badgeId: 'userBadge',
        url:  '{{ url("/admin/data/user-analytics") }}',
        type: 'line',
        options: scaleOpts,
    });

    // ── Top products (horizontal bar) ────────────────────────────────────────
    loadChart({
        canvasId: 'productChart', loaderId: 'productChartLoader',
        emptyId:  'productChartEmpty', badgeId: 'productBadge',
        url:  '{{ url("/admin/data/product-analytics") }}',
        type: 'bar',
        options: {
            indexAxis: 'y',
            responsive: true, maintainAspectRatio: true,
            plugins: { legend: { display: false }, tooltip: tooltipDefaults },
            scales: {
                x: { beginAtZero: true, grid: { color: '#f0f0f0' } },
                y: { grid: { display: false }, ticks: { font: { size: 11 } } },
            },
        },
    });

    // ── Orders per month (bar) ───────────────────────────────────────────────
    loadChart({
        canvasId: 'transactionChart', loaderId: 'transactionChartLoader',
        emptyId:  'transactionChartEmpty', badgeId: 'transactionBadge',
        url:  '{{ url("/admin/data/transaction-analytics") }}',
        type: 'bar',
        options: scaleOpts,
    });

    // ── Orders by status (doughnut) ──────────────────────────────────────────
    loadChart({
        canvasId: 'statusChart', loaderId: 'statusChartLoader',
        emptyId:  'statusChartEmpty', badgeId: 'statusBadge',
        url:  '{{ url("/admin/data/order-status-analytics") }}',
        type: 'doughnut',
        options: {
            responsive: true, maintainAspectRatio: true,
            plugins: {
                legend: { display: true, position: 'bottom', labels: { boxWidth: 12, padding: 10, font: { size: 11 } } },
                tooltip: tooltipDefaults,
            },
            cutout: '62%',
        },
    });

});
</script>
@endsection
